---
name: bd-playbook
description: BD playbook document generation with executive summaries, program intelligence, and outreach strategies. Use when creating Word documents for BD campaigns including program overviews, contact profiles, pain point analysis, and action plans.
---

# BD Playbook Generation

Create comprehensive BD playbook documents with executive summaries, program intelligence, contact profiles, and action plans for targeted outreach campaigns.

**Keywords**: BD playbook, Word document, executive summary, program overview, contact profiles, pain points, past performance, action plan, DCGS

## Document Structure

### Standard 5-Section Layout

1. **Executive Summary** (1 page max)
2. **Program Intelligence** (2-3 pages)
3. **Contact Profiles** (2-4 pages)
4. **PTS Capabilities & Past Performance** (1-2 pages)
5. **Action Plan & Timeline** (1 page)

## Section Templates

### 1. Executive Summary

**Purpose:** One-page overview for leadership

**Content:**
```markdown
# Executive Summary

## Target Opportunity
- **Program:** [PROGRAM NAME]
- **Contract Value:** [VALUE]
- **Prime/Sub:** [RELATIONSHIP]
- **BD Priority:** [🔴 Critical / 🟠 High / 🟡 Medium]

## Strategic Rationale
[2-3 sentences on why this program is a target]

## Key Findings
- [Finding 1 - e.g., "3 open positions at San Diego site"]
- [Finding 2 - e.g., "Acting site lead indicates staffing gaps"]
- [Finding 3 - e.g., "Option year review in Nov 2026"]

## Recommended Actions
1. [Priority action with owner and deadline]
2. [Secondary action]
3. [Follow-up action]

## Success Metrics
- [Metric 1 - e.g., "Schedule 3 discovery calls within 2 weeks"]
- [Metric 2 - e.g., "Submit 2 candidates by month end"]
```

### 2. Program Intelligence

**Purpose:** Deep dive on program details

**Content:**
```markdown
# Program Intelligence

## Program Overview

| Attribute | Value |
|-----------|-------|
| Program Name | [FULL NAME] |
| Acronym | [ACRONYM] |
| Agency/Customer | [AGENCY] |
| Prime Contractor | [PRIME] |
| PTS Relationship | [GDIT Subcontractor Staffing] |
| Contract Vehicle | [VEHICLE] |
| Contract Value | [VALUE] |
| Period of Performance | [START - END] |
| Current Status | [Option Year X / Base / Recompete] |

## Sites & Locations

| Site | Location | Mission | Key Roles |
|------|----------|---------|-----------|
| [SITE 1] | [LOCATION] | [MISSION] | [ROLES] |
| [SITE 2] | [LOCATION] | [MISSION] | [ROLES] |

## Current Pain Points

### [SITE 1] - [LOCATION]
**Source:** [HUMINT / Job Postings / Industry Intel]

- [Pain Point 1 with detail]
- [Pain Point 2 with detail]

**Implication for PTS:** [How this creates opportunity]

### [SITE 2] - [LOCATION]
[Similar structure]

## Labor Gap Analysis

| Position | Location | Days Open | Clearance | Priority |
|----------|----------|-----------|-----------|----------|
| [TITLE 1] | [LOC] | [DAYS] | [CLR] | 🔴 Critical |
| [TITLE 2] | [LOC] | [DAYS] | [CLR] | 🟠 High |

## Competitive Landscape

| Competitor | Presence | Strengths | Weaknesses |
|------------|----------|-----------|------------|
| [COMPETITOR 1] | [ROLE] | [STRENGTHS] | [WEAKNESSES] |
| [COMPETITOR 2] | [ROLE] | [STRENGTHS] | [WEAKNESSES] |
```

### 3. Contact Profiles

**Purpose:** Key contacts for outreach

**Content:**
```markdown
# Contact Profiles

## Priority Contacts

### 🔴 Critical Priority

#### [NAME 1]
- **Title:** [TITLE]
- **Program:** [PROGRAM]
- **Location:** [LOCATION]
- **Contact:** [PHONE] | [EMAIL]
- **LinkedIn:** [URL]

**Background:**
[1-2 sentences on their role and relevance]

**Outreach Strategy:**
[Specific approach based on BD Formula]

**Personalized Opening:**
"[Customized message per BD Formula Step 1]"

---

### 🟠 High Priority

#### [NAME 2]
[Similar structure]

---

### 🟡 Medium Priority

[Additional contacts with abbreviated detail]

## Organizational Chart

[Reference to separate org chart document or embedded visualization]

## Contact Sequencing

| Week | Contact | Action | Channel | CTA |
|------|---------|--------|---------|-----|
| 1 | [NAME] | Initial outreach | LinkedIn | Coffee chat |
| 1 | [NAME] | Follow-up | Email | 30-min call |
| 2 | [NAME] | Introduction | Phone | Capabilities brief |
```

### 4. PTS Capabilities & Past Performance

**Purpose:** Establish credibility

**Content:**
```markdown
# PTS Capabilities & Past Performance

## Company Overview

Prime Technical Services (PTS) is a Service-Disabled Veteran-Owned 
Small Business (SDVOSB) specializing in cleared IT staffing for 
defense contractors and federal agencies.

**Key Differentiators:**
- [Differentiator 1]
- [Differentiator 2]
- [Differentiator 3]

## GDIT Partnership History

| Program | Duration | Roles Provided | Clearance |
|---------|----------|----------------|-----------|
| BICES/BICES-X | 2018-Present | Network Engineers, Analysts | TS/SCI |
| GSM-O II | 2019-Present | Network Engineers | TS/SCI |
| NATO BICES | 2020-Present | Coalition Analysts | TS/SCI |

## Relevant Past Performance

### Similar Programs

| Program | Prime | Relevance | Key Deliverables |
|---------|-------|-----------|------------------|
| [PROGRAM 1] | [PRIME] | [RELEVANCE] | [DELIVERABLES] |
| [PROGRAM 2] | [PRIME] | [RELEVANCE] | [DELIVERABLES] |

### Role-Specific Experience

**For [TARGET ROLE TYPE 1]:**
- [Past performance example]
- [Metrics/outcomes]

**For [TARGET ROLE TYPE 2]:**
- [Past performance example]
- [Metrics/outcomes]

## Current Pipeline

| Role Type | Clearance | Available | Ready |
|-----------|-----------|-----------|-------|
| Network Engineers | TS/SCI | 5 | 2 immediate |
| Intel Analysts | TS/SCI | 8 | 3 immediate |
| Cyber Security | TS/SCI | 4 | 1 immediate |
```

### 5. Action Plan & Timeline

**Purpose:** Clear next steps

**Content:**
```markdown
# Action Plan & Timeline

## Immediate Actions (Week 1)

| Action | Owner | Deadline | Status |
|--------|-------|----------|--------|
| [ACTION 1] | [NAME] | [DATE] | ⬜ Not Started |
| [ACTION 2] | [NAME] | [DATE] | ⬜ Not Started |
| [ACTION 3] | [NAME] | [DATE] | ⬜ Not Started |

## Short-Term Goals (Weeks 2-4)

| Goal | Metric | Target | Owner |
|------|--------|--------|-------|
| [GOAL 1] | [METRIC] | [TARGET] | [NAME] |
| [GOAL 2] | [METRIC] | [TARGET] | [NAME] |

## Campaign Milestones

| Milestone | Target Date | Success Criteria |
|-----------|-------------|------------------|
| Initial Outreach Complete | [DATE] | All priority contacts touched |
| Discovery Calls Scheduled | [DATE] | 3+ calls confirmed |
| Requirements Gathered | [DATE] | Specific positions documented |
| Candidates Submitted | [DATE] | 2+ qualified submissions |
| First Placement | [DATE] | Contractor on site |

## Risk Mitigation

| Risk | Probability | Impact | Mitigation |
|------|-------------|--------|------------|
| [RISK 1] | [H/M/L] | [H/M/L] | [MITIGATION] |
| [RISK 2] | [H/M/L] | [H/M/L] | [MITIGATION] |

## Next Review Date

**Scheduled:** [DATE]
**Participants:** [NAMES]
**Agenda:** Review progress against milestones, adjust strategy as needed
```

## Document Formatting

### Word Document Styles

```python
from docx import Document
from docx.shared import Pt, Inches, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.style import WD_STYLE_TYPE

def create_playbook_document(data, output_path):
    doc = Document()
    
    # Title style
    title_style = doc.styles.add_style('PlaybookTitle', WD_STYLE_TYPE.PARAGRAPH)
    title_style.font.size = Pt(24)
    title_style.font.bold = True
    title_style.font.color.rgb = RGBColor(31, 78, 121)  # Navy blue
    
    # Heading 1 style
    h1_style = doc.styles['Heading 1']
    h1_style.font.size = Pt(16)
    h1_style.font.color.rgb = RGBColor(31, 78, 121)
    
    # Heading 2 style
    h2_style = doc.styles['Heading 2']
    h2_style.font.size = Pt(14)
    h2_style.font.color.rgb = RGBColor(31, 78, 121)
    
    # Add title
    title = doc.add_paragraph(data['title'], style='PlaybookTitle')
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    
    # Add sections
    # ... implementation details
    
    doc.save(output_path)
```

### Table Formatting

```python
from docx.oxml.ns import nsdecls
from docx.oxml import parse_xml

def format_table_with_header(table):
    """Apply professional formatting to table"""
    
    # Header row styling
    header_cells = table.rows[0].cells
    for cell in header_cells:
        cell._tc.get_or_add_tcPr().append(
            parse_xml(r'<w:shd {} w:fill="1F4E79"/>'.format(nsdecls('w')))
        )
        for paragraph in cell.paragraphs:
            for run in paragraph.runs:
                run.font.color.rgb = RGBColor(255, 255, 255)
                run.font.bold = True
    
    # Alternating row colors
    for idx, row in enumerate(table.rows[1:], 1):
        if idx % 2 == 0:
            for cell in row.cells:
                cell._tc.get_or_add_tcPr().append(
                    parse_xml(r'<w:shd {} w:fill="F2F2F2"/>'.format(nsdecls('w')))
                )
```

## Quality Checklist

Before delivering playbook:
- [ ] Executive summary fits on 1 page
- [ ] All [BRACKETS] filled with real data
- [ ] Pain points specific to program (not generic)
- [ ] Contact profiles include personalized messaging
- [ ] Past performance relevant to target
- [ ] Action plan has specific dates and owners
- [ ] Tables formatted consistently
- [ ] No spelling/grammar errors
- [ ] Document follows PTS branding

## Anti-Patterns

- ❌ Generic pain points (use program-specific)
- ❌ Unfilled template brackets [NAME]
- ❌ Past performance not relevant to target
- ❌ Action plan without deadlines
- ❌ Executive summary longer than 1 page
- ❌ Missing contact information
- ❌ No personalized messaging
- ❌ Generic company boilerplate
