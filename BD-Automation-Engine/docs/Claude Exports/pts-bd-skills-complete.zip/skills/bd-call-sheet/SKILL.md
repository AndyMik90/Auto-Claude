---
name: bd-call-sheet
description: BD call sheet generation with priority color-coding and personalized messaging. Use when creating Excel workbooks for outreach campaigns with contacts grouped by priority, phone numbers, emails, LinkedIn links, and customized talking points.
---

# BD Call Sheet Generation

Create professional Excel call sheets with priority color-coding, personalized messaging columns, and tracking fields for BD outreach campaigns.

**Keywords**: call sheet, Excel, outreach, contacts, priority, color coding, phone, email, LinkedIn, talking points, BD campaign

## Call Sheet Structure

### Standard Tab Layout

**Tab 1: Priority Contacts**
- Sorted by BD Priority (Critical → Standard)
- Color-coded rows
- Personalized messaging columns

**Tab 2: Open Jobs**
- DCGS job openings mapped to sites
- Hiring signals for outreach context

**Tab 3: Contact Notes** (optional)
- Extended notes and HUMINT
- Follow-up tracking

## Column Specifications

### Priority Contacts Tab

| Column | Width | Purpose | Format |
|--------|-------|---------|--------|
| A: Priority | 12 | BD Priority emoji | Center |
| B: Name | 25 | First Last | Bold |
| C: Title | 35 | Job Title | Normal |
| D: Program | 20 | Assigned program | Normal |
| E: Phone | 18 | Primary phone | Monospace |
| F: Email | 35 | Email address | Hyperlink |
| G: LinkedIn | 15 | "Profile" link | Hyperlink |
| H: Personalized Message | 50 | BD Formula Step 1 | Wrap text |
| I: Pain Points | 40 | BD Formula Step 2 | Wrap text |
| J: Labor Gaps | 35 | BD Formula Step 3 | Wrap text |
| K: PTS Past Performance | 40 | BD Formula Steps 4-6 | Wrap text |
| L: Call Notes | 30 | Empty for user | Normal |
| M: Status | 12 | Empty dropdown | Normal |
| N: Follow-Up Date | 15 | Empty for user | Date |

## Priority Color Coding

### Color Scheme

| Priority | Background | Text | Hex Code |
|----------|------------|------|----------|
| 🔴 Critical | Light Red | Dark Red | #FFCCCC / #8B0000 |
| 🟠 High | Light Orange | Dark Orange | #FFE5CC / #CC5500 |
| 🟡 Medium | Light Yellow | Dark Yellow | #FFFFCC / #806600 |
| ⚪ Standard | White | Black | #FFFFFF / #000000 |

### Excel Implementation

```python
from openpyxl.styles import PatternFill, Font, Alignment, Border, Side

# Priority fills
PRIORITY_FILLS = {
    '🔴 Critical': PatternFill(start_color='FFCCCC', end_color='FFCCCC', fill_type='solid'),
    '🟠 High': PatternFill(start_color='FFE5CC', end_color='FFE5CC', fill_type='solid'),
    '🟡 Medium': PatternFill(start_color='FFFFCC', end_color='FFFFCC', fill_type='solid'),
    '⚪ Standard': PatternFill(start_color='FFFFFF', end_color='FFFFFF', fill_type='solid'),
}

# Apply to row
def apply_priority_formatting(ws, row_num, priority):
    fill = PRIORITY_FILLS.get(priority, PRIORITY_FILLS['⚪ Standard'])
    for col in range(1, 15):  # Columns A through N
        ws.cell(row=row_num, column=col).fill = fill
```

## Excel Generation Code

### Complete Workbook Generator

```python
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter

def create_bd_call_sheet(contacts_df, jobs_df, output_path):
    """
    Create BD call sheet Excel workbook
    
    Args:
        contacts_df: DataFrame with contact data
        jobs_df: DataFrame with job data
        output_path: Path to save Excel file
    """
    wb = Workbook()
    
    # --- Tab 1: Priority Contacts ---
    ws_contacts = wb.active
    ws_contacts.title = "Priority Contacts"
    
    # Header row
    headers = [
        'Priority', 'Name', 'Title', 'Program', 'Phone', 'Email', 
        'LinkedIn', 'Personalized Message', 'Pain Points', 
        'Labor Gaps', 'PTS Past Performance', 'Call Notes', 
        'Status', 'Follow-Up Date'
    ]
    
    header_fill = PatternFill(start_color='1F4E79', end_color='1F4E79', fill_type='solid')
    header_font = Font(bold=True, color='FFFFFF')
    
    for col, header in enumerate(headers, 1):
        cell = ws_contacts.cell(row=1, column=col, value=header)
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal='center', vertical='center')
    
    # Sort by priority
    priority_order = {'🔴 Critical': 0, '🟠 High': 1, '🟡 Medium': 2, '⚪ Standard': 3}
    contacts_df['_sort'] = contacts_df['BD Priority'].map(priority_order)
    contacts_df = contacts_df.sort_values('_sort').drop('_sort', axis=1)
    
    # Add data rows
    for idx, contact in contacts_df.iterrows():
        row_num = idx + 2
        
        # Priority
        ws_contacts.cell(row=row_num, column=1, value=contact.get('BD Priority', '⚪ Standard'))
        
        # Name (bold)
        name_cell = ws_contacts.cell(row=row_num, column=2, 
                                     value=f"{contact.get('First Name', '')} {contact.get('Last Name', '')}")
        name_cell.font = Font(bold=True)
        
        # Title
        ws_contacts.cell(row=row_num, column=3, value=contact.get('Job Title', ''))
        
        # Program
        ws_contacts.cell(row=row_num, column=4, value=contact.get('Program', ''))
        
        # Phone (monospace)
        phone_cell = ws_contacts.cell(row=row_num, column=5, value=contact.get('Phone Number', ''))
        phone_cell.font = Font(name='Consolas')
        
        # Email (hyperlink)
        email = contact.get('Email Address', '')
        if email:
            ws_contacts.cell(row=row_num, column=6, value=email)
            ws_contacts.cell(row=row_num, column=6).hyperlink = f"mailto:{email}"
            ws_contacts.cell(row=row_num, column=6).font = Font(color='0563C1', underline='single')
        
        # LinkedIn (hyperlink)
        linkedin = contact.get('LinkedIn Contact Profile URL', '')
        if linkedin:
            ws_contacts.cell(row=row_num, column=7, value='Profile')
            ws_contacts.cell(row=row_num, column=7).hyperlink = linkedin
            ws_contacts.cell(row=row_num, column=7).font = Font(color='0563C1', underline='single')
        
        # Personalized Message
        msg_cell = ws_contacts.cell(row=row_num, column=8, 
                                    value=generate_personalized_message(contact))
        msg_cell.alignment = Alignment(wrap_text=True, vertical='top')
        
        # Pain Points
        pain_cell = ws_contacts.cell(row=row_num, column=9, 
                                     value=get_program_pain_points(contact.get('Program', '')))
        pain_cell.alignment = Alignment(wrap_text=True, vertical='top')
        
        # Labor Gaps
        gaps_cell = ws_contacts.cell(row=row_num, column=10, 
                                     value=get_labor_gaps(contact.get('Program', ''), jobs_df))
        gaps_cell.alignment = Alignment(wrap_text=True, vertical='top')
        
        # PTS Past Performance
        pp_cell = ws_contacts.cell(row=row_num, column=11, 
                                   value=get_relevant_past_performance(contact))
        pp_cell.alignment = Alignment(wrap_text=True, vertical='top')
        
        # Apply priority color coding
        apply_priority_formatting(ws_contacts, row_num, contact.get('BD Priority', '⚪ Standard'))
    
    # Column widths
    col_widths = [12, 25, 35, 20, 18, 35, 15, 50, 40, 35, 40, 30, 12, 15]
    for col, width in enumerate(col_widths, 1):
        ws_contacts.column_dimensions[get_column_letter(col)].width = width
    
    # Row height for wrapped text
    for row in range(2, len(contacts_df) + 2):
        ws_contacts.row_dimensions[row].height = 80
    
    # Freeze header row
    ws_contacts.freeze_panes = 'A2'
    
    # --- Tab 2: Open Jobs ---
    ws_jobs = wb.create_sheet("Open Jobs")
    # ... similar implementation for jobs tab
    
    # Save
    wb.save(output_path)
    return output_path
```

## Personalized Message Generation

### BD Formula Implementation

```python
def generate_personalized_message(contact):
    """Generate personalized opening based on BD Formula Step 1"""
    
    name = contact.get('First Name', '')
    title = contact.get('Job Title', '')
    program = contact.get('Program', '')
    location = contact.get('Location Hub', '')
    
    # Map program to specific context
    program_context = {
        'AF DCGS - Langley': "supporting the 480th ISR Wing's DCGS operations",
        'AF DCGS - PACAF': "working on the critical PACAF node in San Diego",
        'AF DCGS - Wright-Patt': "supporting NASIC's technical intelligence mission",
        'Army DCGS-A': "working on Army DCGS-A intelligence production",
        'Navy DCGS-N': "supporting Navy DCGS-N fleet intelligence",
        'Corporate HQ': "leading GDIT's defense intelligence portfolio",
    }
    
    context = program_context.get(program, f"supporting {program} operations")
    
    return f"Hi {name}, I noticed you're {context}. Given your work as {title}..."

def get_program_pain_points(program):
    """Get known pain points for program (BD Formula Step 2)"""
    
    pain_points = {
        'AF DCGS - PACAF': "Acting site lead stretched thin, single points of failure, no redundancy for key roles",
        'AF DCGS - Langley': "High ISR volume, analyst burnout, PMO pressure on filling vacancies quickly",
        'AF DCGS - Wright-Patt': "Radar engineer vacancy open 6+ months, DevSecOps shortage for modernization",
        'Army DCGS-A': "Surge staffing needs, coordination challenges across dispersed sites",
        'Navy DCGS-N': "Ship/shore integration challenges, Norfolk talent market competition",
    }
    
    return pain_points.get(program, "Staffing challenges and workforce continuity")

def get_relevant_past_performance(contact):
    """Get PTS past performance relevant to contact (BD Formula Steps 4-6)"""
    
    program = contact.get('Program', '')
    title = contact.get('Job Title', '').lower()
    
    # Base GDIT past performance
    base_pp = "BICES/BICES-X (TS/SCI network engineers), GSM-O II (24/7 DISA ops)"
    
    # Program-relevant additions
    program_pp = {
        'AF DCGS': "SOCOM JICCENT (Joint Intel), Platform One (USAF DevSecOps)",
        'Army DCGS-A': "Army RS3 (C4ISR engineers), INSCOM support",
        'Navy DCGS-N': "DIA I2OS (software integration), NATO BICES",
    }
    
    # Role-relevant additions
    if 'network' in title:
        role_pp = "DISA/coalition network experience"
    elif 'cyber' in title or 'security' in title:
        role_pp = "Cleared cyber portfolio (JRSS, BICES)"
    elif 'intel' in title or 'analyst' in title:
        role_pp = "IC analyst placements"
    else:
        role_pp = "Cleared technical talent"
    
    for key, pp in program_pp.items():
        if key in program:
            return f"{base_pp}\n{pp}\n{role_pp}"
    
    return f"{base_pp}\n{role_pp}"
```

## Excel Styling Best Practices

### Header Row
- Background: Navy blue (#1F4E79)
- Text: White, Bold
- Alignment: Center
- Freeze panes enabled

### Data Rows
- Alternating colors optional
- Priority color-coding primary
- Wrap text for message columns
- Row height: 80-120 pixels for wrapped content

### Phone Numbers
- Monospace font (Consolas)
- Format: (XXX) XXX-XXXX

### Hyperlinks
- Blue underlined text
- Email: mailto: protocol
- LinkedIn: Direct URL

## Quality Checklist

Before delivering call sheet:
- [ ] Contacts sorted by priority (Critical first)
- [ ] All priority rows color-coded correctly
- [ ] Phone numbers formatted consistently
- [ ] Email/LinkedIn hyperlinks working
- [ ] Personalized messages populated (no [BRACKETS])
- [ ] Pain points specific to program
- [ ] Past performance relevant to role
- [ ] Header row frozen
- [ ] Column widths readable
- [ ] No duplicate contacts
