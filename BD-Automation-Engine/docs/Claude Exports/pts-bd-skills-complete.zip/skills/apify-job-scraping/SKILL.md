---
name: apify-job-scraping
description: Apify job scraping configuration for BD intelligence gathering. Use when setting up job scrapers, selecting actors, optimizing costs, or processing competitor staffing portal data from Insight Global, Apex Systems, TEKsystems, and other sources.
---

# Apify Job Scraping

Configure and optimize Apify scrapers for competitor job board intelligence gathering. Includes actor selection, cost optimization, and data processing patterns.

**Keywords**: Apify, job scraper, Puppeteer, web scraping, Insight Global, Apex Systems, TEKsystems, LinkedIn jobs, Indeed, competitor intelligence

## Scraping Targets

### Competitor Staffing Portals (Primary)

| Portal | Actor | Cost | Data Quality |
|--------|-------|------|--------------|
| Insight Global | Puppeteer Scraper | ~$0.05/run | URL + Location only |
| Apex Systems | Puppeteer Scraper | ~$0.05/run | Rich (11 fields) |
| TEKsystems | Puppeteer Scraper | ~$0.05/run | Medium |
| CACI | Puppeteer Scraper | ~$0.05/run | Medium |

### Job Boards (Secondary)

| Source | Actor | Cost | Notes |
|--------|-------|------|-------|
| LinkedIn | curious_coder/linkedin-jobs-scraper | $1/1000 jobs | Best for hiring manager names |
| Indeed | valig/indeed-jobs-scraper | $0.0001/job | Cheapest, good coverage |
| Clearance Jobs | Custom scraper | Variable | Defense-specific |

## Puppeteer Scraper Configuration

### Basic Setup

```javascript
// Actor: apify/puppeteer-scraper

{
  "startUrls": [
    {"url": "https://www.insightglobal.com/jobs?search=DCGS"}
  ],
  "pageFunction": async function pageFunction(context) {
    const { page, request, log } = context;
    const title = await page.title();
    
    // Extract job data
    const jobs = await page.$$eval('.job-card', cards => {
      return cards.map(card => ({
        title: card.querySelector('.job-title')?.textContent?.trim(),
        location: card.querySelector('.location')?.textContent?.trim(),
        url: card.querySelector('a')?.href,
        company: 'Insight Global'
      }));
    });
    
    return jobs;
  },
  "proxyConfiguration": {
    "useApifyProxy": true
  },
  "maxConcurrency": 10,
  "maxRequestsPerCrawl": 500
}
```

### Search Configuration by Target

**Insight Global:**
```json
{
  "startUrls": [
    {"url": "https://www.insightglobal.com/jobs?search=intelligence+analyst"},
    {"url": "https://www.insightglobal.com/jobs?search=network+engineer"},
    {"url": "https://www.insightglobal.com/jobs?search=DCGS"},
    {"url": "https://www.insightglobal.com/jobs?search=TS%2FSCI"}
  ]
}
```

**Apex Systems:**
```json
{
  "startUrls": [
    {"url": "https://www.apexsystems.com/job-seekers/job-search?keywords=intelligence"},
    {"url": "https://www.apexsystems.com/job-seekers/job-search?keywords=clearance"},
    {"url": "https://www.apexsystems.com/job-seekers/job-search?keywords=GDIT"}
  ]
}
```

## Output Schema

### Standard Fields (All Scrapers)

```json
{
  "title": "Network Engineer",
  "company": "Insight Global",
  "location": "San Diego, CA",
  "url": "https://...",
  "detected_clearance": "TS/SCI",
  "primary_keyword": "network",
  "scraped_at": "2026-01-06T01:56:50.487Z"
}
```

### Extended Fields (Rich Sources like Apex)

```json
{
  "title": "Intelligence Analyst",
  "company": "Apex Systems",
  "location": "Hampton, VA",
  "url": "https://...",
  "description": "Full job description text...",
  "datePosted": "2026-01-02",
  "payRate": "$85-95/hour",
  "duration": "12+ months",
  "employmentType": "Contract",
  "securityClearance": "TS/SCI Required",
  "jobNumber": "APX-2026-001",
  "scraped_at": "2026-01-06T01:56:50.487Z"
}
```

## Clearance Detection

### Clearance Patterns

```python
CLEARANCE_PATTERNS = {
    'TS/SCI w/ FS Poly': r'ts/sci.*full.?scope|full.?scope.*poly',
    'TS/SCI w/ CI Poly': r'ts/sci.*ci.?poly|ci.?poly.*ts/sci',
    'TS/SCI': r'ts/sci|top.?secret/sci',
    'Top Secret': r'top.?secret(?!/sci)',
    'Secret': r'(?<!top.)secret',
    'Public Trust': r'public.?trust',
}

def detect_clearance(text):
    text_lower = text.lower()
    for clearance, pattern in CLEARANCE_PATTERNS.items():
        if re.search(pattern, text_lower):
            return clearance
    return None
```

## Cost Optimization

### Cost Comparison

| Strategy | Jobs/Month | Monthly Cost | Notes |
|----------|------------|--------------|-------|
| Full scrape all sources | 5,000 | ~$30 | Comprehensive |
| Targeted DCGS only | 500 | ~$3 | Focused |
| LinkedIn + Indeed | 2,000 | ~$2.50 | Job boards only |
| Competitor portals only | 1,000 | ~$5 | Staffing firms |

### Two-Stage Approach (Recommended)

**Stage 1: Lightweight Universal Scrape**
- All sources, basic fields only
- Cost: ~$0.001/job
- Get: Title, Location, URL, Clearance

**Stage 2: Deep Enrichment (High Priority Only)**
- Jobs scoring >70 BD Priority
- Cost: ~$0.02/job (LLM enrichment)
- Get: Full standardization, program mapping

**Savings:** ~79% compared to full enrichment of all jobs

## MCP Tool Usage

### Search for Available Actors

```
apify:search-actors
  keywords="LinkedIn jobs"
  limit=5
```

### Get Actor Details

```
apify:fetch-actor-details
  actor="apify/puppeteer-scraper"
```

### Run Actor

```
apify:apify-slash-puppeteer-scraper
  startUrls=[{"url": "https://..."}]
  pageFunction="..."
  proxyConfiguration={"useApifyProxy": true}
```

### Get Run Output

```
apify:get-actor-output
  datasetId="[DATASET_ID]"
  limit=100
```

## Scheduling

### Recommended Cadence

| Source | Frequency | Reason |
|--------|-----------|--------|
| Competitor portals | Weekly | Sufficient for BD intel |
| LinkedIn | Weekly | Rate limit considerations |
| Indeed | Daily (optional) | Cheap, high volume |

### n8n Integration

**Webhook trigger on actor completion:**
```
POST https://primetech.app.n8n.cloud/webhook/apify-job-import
Content-Type: application/json

{
  "runId": "[RUN_ID]",
  "datasetId": "[DATASET_ID]",
  "actorId": "[ACTOR_ID]",
  "status": "SUCCEEDED"
}
```

## Data Processing Pipeline

### Step 1: Import to Notion

Target: Program Mapping Intelligence Hub
Status: `raw_import`

### Step 2: Clearance Extraction

```python
def extract_clearance_from_job(job):
    # Check explicit field first
    if job.get('securityClearance'):
        return normalize_clearance(job['securityClearance'])
    
    # Check title
    clearance = detect_clearance(job.get('title', ''))
    if clearance:
        return clearance
    
    # Check description
    clearance = detect_clearance(job.get('description', ''))
    return clearance
```

### Step 3: Location Normalization

```python
def normalize_location(raw_location):
    # Remove extra whitespace
    location = ' '.join(raw_location.split())
    
    # Standardize common variations
    replacements = {
        'Washington DC': 'Washington, DC',
        'Ft. Meade': 'Fort George G. Meade, MD',
        'Ft. Belvoir': 'Fort Belvoir, VA',
        '100% Remote': 'Remote'
    }
    
    for old, new in replacements.items():
        if old.lower() in location.lower():
            location = location.replace(old, new)
    
    return location
```

### Step 4: Program Mapping

Use program-mapping skill for matching.

## Error Handling

### Common Errors

| Error | Cause | Solution |
|-------|-------|----------|
| 403 Forbidden | Rate limited | Use proxy, reduce concurrency |
| Timeout | Slow page load | Increase timeout, retry |
| Empty results | Selector changed | Update pageFunction |
| Duplicate jobs | Repeat scrapes | Dedup by URL |

### Retry Logic

```javascript
// In Puppeteer Scraper config
{
  "maxRequestRetries": 3,
  "requestHandlerTimeoutSecs": 60
}
```

## Quality Assurance

### Post-Scrape Validation

- [ ] Job count within expected range
- [ ] All required fields populated
- [ ] Dates in valid format
- [ ] URLs are valid
- [ ] No duplicate entries
- [ ] Clearance detection working

### Monitoring

Check Apify dashboard for:
- Run success rate (target: >95%)
- Cost per job (target: <$0.01)
- Data completeness
- Error logs
